window.onload = function() {

	var selectedSeat = {x: -1, y: -1}; //indexes of selected seat
	var seats = new Array(); //tracks the availables seats

	seats = [[true, false, false, true, true, true, false, true, false],
			[false, true, false, false, true, false, true, true, true],
			[true, true, true, true, true, true, false, true, false],
			[true, true, true, false, true, false, false, true, false]];
	initSeatWithStandardFor();
	findSeat();

	function initSeatWithStandardFor() {
		for (var i = 0; i < seats.length; i++) {
			for (var j = 0; j< seats[i].length; j++) {
				document.getElementById('seat' + i + "x" + j).src = seats[i][j] ? "seat.jpg" : "seat_unavailable.png";
				document.getElementById('seat' + i + "x" + j).alt = seats[i][j] ? "Available!!" : "mhh.... try again later";
			}
			
		}	
	}

	function initSeatWithForEach() {
		for (var a in seats) {
			for (var b in seats[a]) {
				document.getElementById('seat' + a + "x" + b).src = (seats[a][b] ? "seat.jpg" : "seat_unavailable.png");
				document.getElementById('seat' + a + "x" + b).alt = (seats[a][b] ? "Available!!" : "mhh.... try again later");
			}
		}
	}

	function findSeat() {
		if (selectedSeat.x >= 0) {
			selectedSeat = {x: -1, y: -1};
			initSeatWithForEach();
		}
		for (var j = 0; j < seats.length; j++) {
			for (var i = 0; i < seats[j].length; i++) {
				if (seats[j][i] && seats[j][i + 1] && seats[j][i + 2]) {
					selectedSeat = {x: j, y: i};
					document.getElementById("seat" + j + "x" + i).src = "seat_selected.png";
					document.getElementById("seat" + j + "x" + i).alt = "Available!!";
					document.getElementById("seat" + j + "x" + (i + 1)).src = "seat_selected.png";
					document.getElementById("seat" + j + "x" + (i + 1)).alt = "Available!!";
					document.getElementById("seat" + j + "x" + (i + 2)).src = "seat_selected.png";
					document.getElementById("seat" + j + "x" + (i + 2)).alt = "Available!!";

					var accept = confirm("seats " + (j + 1) + "x" + (i + 1) + " through " + (j + 1) + "x" + (i + 3) + " are available. Wanna confirm?");

					if (accept) {
						return;
					} else {
						selectedSeat = -1;
						document.getElementById("seat" + j + "x" + i).src = "seat.jpg";
						document.getElementById("seat" + j + "x" + i).alt = "Get this moa!";
						document.getElementById("seat" + j + "x" + (i + 1)).src = "seat.jpg";
						document.getElementById("seat" + j + "x" + (i + 1)).alt = "Get this moa!";
						document.getElementById("seat" + j + "x" + (i + 2)).src = "seat.jpg";
						document.getElementById("seat" + j + "x" + (i + 2)).alt = "Get this moa!";
					}
				}
			}
		}
		alert("ma che ce se' venuto a fa!?!?");
	}

}