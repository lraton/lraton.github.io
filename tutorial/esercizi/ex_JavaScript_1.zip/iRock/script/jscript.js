function load(){
	alert("Hello! iRock here!");
}
function touchRock(){
	var userName = prompt("What's yor name?", "Name here ^^");
	if (userName) {
		alert ("It's good to meet ya, "+userName+"!");
		document.getElementById("stone").src = "images/rock_happy.png";
	}
}
